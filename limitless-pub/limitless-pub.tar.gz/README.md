LIght-weight MonItoring Tool for LargE Scale distributed System

Framework that combines global system monitorization with application level monitorization. The objective is to schedule and manage the whole cluster to exploit the available resources reducing the application's execution time.

Documentation included in the repository.




