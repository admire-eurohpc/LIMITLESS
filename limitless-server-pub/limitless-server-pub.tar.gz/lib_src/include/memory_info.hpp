#ifndef MEM_INFO_H
#define MEM_INFO_H


int read_memory_stats();
int get_mem_total(int & memtotal);

#endif
